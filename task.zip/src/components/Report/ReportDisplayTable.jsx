import * as React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import { Checkbox } from "@mui/material";
import PictureAsPdfIcon from "@mui/icons-material/PictureAsPdf";
import { useNavigate } from "react-router";

const label = { inputProps: { "aria-label": "Checkbox demo" } };
function createData(id, vender,  date) {
  return { id, vender, date };
}

const rows = [
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),
  createData(90, 1007395263589236,  "28-09-2023"),

];

export default function ReportDisplayTable() {
 

  const navigate = useNavigate();

  const handleClickPdf = () => {
    navigate("/approvalTableDSM");
  };

  return (
    <TableContainer component={Paper}>
      <Table sx={{ width: 550 }} aria-label="simple table">
        <TableHead>
          <TableRow
            sx={{
              backgroundColor: "#2B2861",
              color: "#FFFFFF",
            }}
          >
            <TableCell style={{ color: "#FFFFFF" }} align="center">Serial No</TableCell>
            <TableCell style={{ color: "#FFFFFF" }} align="center">
            Transition id
            </TableCell>
           
           
            <TableCell style={{ color: "#FFFFFF" }} align="center">
              Date
            </TableCell>

           

            
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.id}
              sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
            >
             
              <TableCell
                align="center"
                size="small"
               
                sx={{
                  cursor: "pointer",
                }}
              >
                {row.id}
              </TableCell>
              <TableCell align="center" size="small">
                {row.vender}
              </TableCell>
              <TableCell align="center" size="small"  onClick={handleClickPdf}>
                {row.date}
              </TableCell>
             
             
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
