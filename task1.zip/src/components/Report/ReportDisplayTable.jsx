import * as React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

import { useNavigate } from "react-router";
import { Box } from "@mui/material";

import Report from "../../assets/Report.jpeg";

function createData(id, vender, date) {
  return { id, vender, date };
}

const rows = [
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
  createData(90, 1007395263589236, "28-09-2023"),
];

export default function ReportDisplayTable() {
  const [showPdfBox, setShowPdfBox] = React.useState(false);
  const [selectedRow, setSelectedRow] = React.useState(null);
  const navigate = useNavigate();

  const handleClickPdf = (row) => {
    setSelectedRow(row);
    setShowPdfBox(true);
  };

  const handleClosePdfBox = () => {
    setShowPdfBox(false);
  };

  return (
    <>
      <TableContainer sx={{}}>
        <Table sx={{ width: 550, boxShadow: 1 }} aria-label="simple table">
          <TableHead>
            <TableRow
              sx={{
                backgroundColor: "#2B2861",
                color: "#FFFFFF",
              }}
            >
              <TableCell style={{ color: "#FFFFFF" }} align="center">
                Serial No
              </TableCell>
              <TableCell style={{ color: "#FFFFFF" }} align="center">
                Transition id
              </TableCell>

              <TableCell style={{ color: "#FFFFFF" }} align="center">
                Date
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <TableRow
                key={row.id}
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell
                  align="center"
                  size="small"
                  sx={{
                    cursor: "pointer",
                  }}
                >
                  {row.id}
                </TableCell>
                <TableCell align="center" size="small">
                  {row.vender}
                </TableCell>
                <TableCell
                  align="center"
                  size="small"
                  onClick={() => handleClickPdf(row)}
                >
                  {row.date}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      {showPdfBox && (
        <Box
          sx={{
            position: "absolute",
            right: "50px",
            top: "150px",
            padding: 1,
            backgroundColor: "white",
            boxShadow: 2,
            zIndex: 1,
            width: "500px",
            height: "auto",
          }}
        >
          <div
            style={{
              width: "500px",
              height: "480px",
              border: "2px solid black",
            }}
          >
            <img src={Report} alt="report" srcset=""  style={{
               width: "495px",
               height: "475px",
            }} />
          </div>
        </Box>
      )}
    </>
  );
}
